// aiService.js
// Feature 1: Profile-Aware Questioning and Evaluation
// Feature 2: Conversational and Adaptive Interviewing
//
// If ANTHROPIC_API_KEY is set, real LLM calls are used for higher quality
// questions/evaluations. Otherwise a deterministic rule-based fallback runs,
// so the prototype works fully offline out of the box.

const HAS_LLM = !!process.env.ANTHROPIC_API_KEY;

async function callClaude(systemPrompt, userPrompt) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 800,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }]
    })
  });
  const data = await res.json();
  const text = (data.content || []).map((b) => b.text || "").join("\n");
  return text;
}

// ---- Very small keyword/skill extractor used by the rule-based fallback ----
const SKILL_BANK = [
  "javascript", "python", "java", "react", "node", "sql", "aws", "docker",
  "kubernetes", "machine learning", "data analysis", "communication",
  "leadership", "project management", "design", "testing", "api",
  "c++", "c#", "git", "agile", "product", "marketing", "sales"
];

function extractSkills(resumeText) {
  const lower = resumeText.toLowerCase();
  const found = SKILL_BANK.filter((s) => lower.includes(s));
  return found.length ? found : ["your background"];
}

function generateQuestionsFallback(resumeText, role) {
  const skills = extractSkills(resumeText).slice(0, 4);
  const questions = [
    `Walk me through your background and what draws you to the ${role} role.`,
    ...skills.map(
      (s) => `Tell me about a project where you applied ${s}. What was your specific contribution?`
    ),
    `Describe a time something went wrong in your work. How did you handle it?`,
    `Why do you think you're a strong fit for a ${role} position, based on your experience?`
  ];
  return questions.slice(0, 5);
}

async function generateQuestions(resumeText, role) {
  if (!HAS_LLM) return generateQuestionsFallback(resumeText, role);

  const sys = `You are an expert technical recruiter. Generate exactly 5 concise interview questions personalized to the candidate's resume and target role. Return ONLY a JSON array of strings, nothing else.`;
  const user = `Target role: ${role}\n\nResume:\n${resumeText}`;
  try {
    const raw = await callClaude(sys, user);
    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    if (Array.isArray(parsed) && parsed.length) return parsed.slice(0, 5);
  } catch (e) {
    console.error("LLM question generation failed, using fallback:", e.message);
  }
  return generateQuestionsFallback(resumeText, role);
}

// ---- Adaptive follow-up logic ----
function decideFollowUpFallback(answerText) {
  const wordCount = answerText.trim().split(/\s+/).filter(Boolean).length;
  if (wordCount < 12) {
    return "Could you go a bit deeper — what exactly did you do, and what was the outcome?";
  }
  if (/\b(i think|maybe|not sure|probably)\b/i.test(answerText)) {
    return "You sounded a little unsure there — can you give a concrete example to back that up?";
  }
  return null; // no follow-up needed, move to next question
}

async function decideFollowUp(question, answerText) {
  if (!HAS_LLM) return decideFollowUpFallback(answerText);

  const sys = `You are conducting a live interview. Decide if the candidate's answer needs a brief probing follow-up question, or if it was thorough enough to move on. If a follow-up is needed, return it as plain text. If the answer is sufficient, return exactly: NONE`;
  const user = `Question: ${question}\nCandidate answer: ${answerText}`;
  try {
    const raw = (await callClaude(sys, user)).trim();
    if (/^none$/i.test(raw)) return null;
    return raw;
  } catch (e) {
    console.error("LLM follow-up failed, using fallback:", e.message);
    return decideFollowUpFallback(answerText);
  }
}

// ---- Final evaluation report ----
function generateReportFallback(transcript, integrityEvents) {
  const totalWords = transcript.reduce(
    (sum, t) => sum + t.answer.trim().split(/\s+/).filter(Boolean).length,
    0
  );
  const avgWords = Math.round(totalWords / Math.max(transcript.length, 1));
  const strengths = [];
  const gaps = [];

  if (avgWords >= 40) strengths.push("Gave detailed, well-elaborated answers.");
  else gaps.push("Answers were often brief; more concrete detail would help.");

  const followUpsTriggered = transcript.filter((t) => t.followUp).length;
  if (followUpsTriggered <= 1) strengths.push("Mostly answered thoroughly on the first attempt.");
  else gaps.push("Needed follow-up prompts on several questions to get full detail.");

  const integrityFlags = integrityEvents.filter((e) => e.type === "attention_lost").length;
  let integrityNote = "No significant attention/integrity concerns were detected.";
  if (integrityFlags > 5) {
    integrityNote = `Attention appeared to drift away from the screen ${integrityFlags} times during the session — worth a closer look.`;
    gaps.push("Frequent attention shifts away from the interview screen.");
  } else if (integrityFlags > 0) {
    integrityNote = `Minor attention shifts detected (${integrityFlags} instance(s)), within normal range.`;
  }

  return {
    summary: `The candidate completed ${transcript.length} question(s) with an average answer length of ${avgWords} words.`,
    strengths: strengths.length ? strengths : ["Completed the interview in full."],
    gaps: gaps.length ? gaps : ["No major gaps identified from this session alone."],
    integrityNote,
    recommendation:
      avgWords >= 40 && followUpsTriggered <= 1
        ? "Recommended to advance to the next round."
        : "Borderline — consider a follow-up conversation before deciding."
  };
}

async function generateReport(transcript, integrityEvents, role) {
  if (!HAS_LLM) return generateReportFallback(transcript, integrityEvents);

  const sys = `You are an expert recruiter writing a candidate evaluation. Return ONLY a JSON object with keys: summary (string), strengths (array of strings), gaps (array of strings), integrityNote (string), recommendation (string). Be fair, specific, and concise.`;
  const user = `Target role: ${role}\n\nTranscript:\n${transcript
    .map((t, i) => `Q${i + 1}: ${t.question}\nA${i + 1}: ${t.answer}${t.followUp ? `\nFollow-up: ${t.followUp}\nFollow-up answer: ${t.followUpAnswer || ""}` : ""}`)
    .join("\n\n")}\n\nIntegrity events logged during session: ${integrityEvents.length} (type breakdown: ${JSON.stringify(
    integrityEvents.reduce((acc, e) => ((acc[e.type] = (acc[e.type] || 0) + 1), acc), {})
  )})`;

  try {
    const raw = await callClaude(sys, user);
    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    if (parsed && parsed.summary) return parsed;
  } catch (e) {
    console.error("LLM report generation failed, using fallback:", e.message);
  }
  return generateReportFallback(transcript, integrityEvents);
}

module.exports = { generateQuestions, decideFollowUp, generateReport, HAS_LLM };

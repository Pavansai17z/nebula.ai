require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const interviewRoutes = require("./routes/interview");
const { HAS_LLM } = require("./services/aiService");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

app.use("/api", interviewRoutes);

app.get("/api/health", (req, res) => {
  res.json({ ok: true, mode: HAS_LLM ? "llm-powered" : "rule-based-fallback" });
});

app.listen(PORT, () => {
  console.log(`AI Interview Bot running at http://localhost:${PORT}`);
  console.log(`Mode: ${HAS_LLM ? "LLM-powered (Anthropic API key detected)" : "Rule-based fallback (no API key set)"}`);
});

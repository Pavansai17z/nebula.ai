const express = require("express");
const crypto = require("crypto");
const { generateQuestions, decideFollowUp, generateReport } = require("../services/aiService");

const router = express.Router();

// In-memory session store (fine for a prototype; swap for a DB in production)
const sessions = new Map();

// ---- POST /api/start ----
// Body: { resume: string, role: string }
router.post("/start", async (req, res) => {
  try {
    const { resume, role } = req.body;
    if (!resume || !role) {
      return res.status(400).json({ error: "resume and role are required" });
    }

    const questions = await generateQuestions(resume, role);
    const sessionId = crypto.randomUUID();

    sessions.set(sessionId, {
      role,
      resume,
      questions,
      currentIndex: 0,
      awaitingFollowUp: false,
      transcript: [],
      integrityEvents: [],
      createdAt: Date.now()
    });

    res.json({ sessionId, totalQuestions: questions.length, firstQuestion: questions[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to start interview" });
  }
});

// ---- POST /api/answer ----
// Body: { sessionId, answerText }
router.post("/answer", async (req, res) => {
  try {
    const { sessionId, answerText } = req.body;
    const session = sessions.get(sessionId);
    if (!session) return res.status(404).json({ error: "Session not found" });
    if (!answerText || !answerText.trim()) {
      return res.status(400).json({ error: "answerText is required" });
    }

    const idx = session.currentIndex;
    const currentQuestion = session.questions[idx];

    if (session.awaitingFollowUp) {
      // This answer responds to the follow-up question
      const entry = session.transcript[session.transcript.length - 1];
      entry.followUpAnswer = answerText;
      session.awaitingFollowUp = false;
      session.currentIndex += 1;
    } else {
      // This answer responds to the main question; decide if we probe deeper
      const followUp = await decideFollowUp(currentQuestion, answerText);
      session.transcript.push({ question: currentQuestion, answer: answerText, followUp: followUp || null });

      if (followUp) {
        session.awaitingFollowUp = true;
        return res.json({ done: false, followUp });
      }
      session.currentIndex += 1;
    }

    const done = session.currentIndex >= session.questions.length;
    if (done) {
      return res.json({ done: true });
    }
    res.json({ done: false, nextQuestion: session.questions[session.currentIndex] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to process answer" });
  }
});

// ---- POST /api/integrity-event ----
// Body: { sessionId, type, detail, timestamp }
router.post("/integrity-event", (req, res) => {
  const { sessionId, type, detail } = req.body;
  const session = sessions.get(sessionId);
  if (!session) return res.status(404).json({ error: "Session not found" });
  session.integrityEvents.push({ type, detail, timestamp: Date.now() });
  res.json({ ok: true });
});

// ---- POST /api/end ----
// Body: { sessionId }
router.post("/end", async (req, res) => {
  try {
    const { sessionId } = req.body;
    const session = sessions.get(sessionId);
    if (!session) return res.status(404).json({ error: "Session not found" });

    const report = await generateReport(session.transcript, session.integrityEvents, session.role);
    res.json({
      report,
      transcript: session.transcript,
      integrityEventCount: session.integrityEvents.length
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to generate report" });
  }
});

module.exports = router;

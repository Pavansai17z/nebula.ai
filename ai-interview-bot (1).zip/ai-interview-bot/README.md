# AI-Powered Interview Bot 🎙️

A working prototype for **Problem Statement 2 (AI/ML Track)**: an AI-powered interview
platform that conducts personalized, adaptive interviews and monitors interview
integrity — built to satisfy the three required key features:

| Feature | Where it lives |
|---|---|
| **Profile-Aware Questioning & Evaluation** | `server/services/aiService.js` → `generateQuestions()`, `generateReport()` |
| **Conversational & Adaptive Interviewing** | `server/services/aiService.js` → `decideFollowUp()` + speech input/output in `public/app.js` |
| **Interview Integrity Monitoring** | `public/app.js` → webcam + tab-focus tracking + face-api.js detection |

The app runs **fully offline in demo mode** using rule-based logic, and automatically
upgrades to real LLM-powered questioning/evaluation the moment you add an Anthropic API
key — no code changes needed.

---

## ✨ Features in detail

1. **Profile-Aware Questioning and Evaluation**
   Paste a resume and a target role. The app extracts relevant skills/experience and
   generates 5 personalized interview questions. At the end, it produces a full
   evaluation report (strengths, gaps, recommendation).

2. **Conversational and Adaptive Interviewing**
   Answers are analyzed as you go — short or hedgy answers automatically trigger a
   probing follow-up question before moving on, simulating a real interviewer. Supports
   both typed answers and **spoken answers** (via the browser's speech recognition),
   with questions read aloud via speech synthesis.

3. **Interview Integrity Monitoring**
   The candidate's webcam feed is monitored for face presence (via `face-api.js`), and
   tab/window focus is tracked. Every attention lapse is logged with a timestamp and
   surfaced transparently in the final report.

---

## 🚀 Running it locally

**Requirements:** Node.js 18+ (uses the built-in `fetch` API)

```bash
# 1. Install dependencies
npm install

# 2. (Optional) enable real LLM-powered questions/evaluations
cp .env.example .env
# then edit .env and paste your ANTHROPIC_API_KEY

# 3. Start the server
npm start

# 4. Open the app
# Visit http://localhost:3000 in Chrome (for best speech-recognition support)
```

Without an API key, the app runs in **rule-based demo mode** — fully functional, just
less nuanced than a real LLM. This is intentional so the prototype works for anyone
grading/reviewing it with zero setup cost.

---

## 📁 Project structure

```
ai-interview-bot/
├── server/
│   ├── index.js              # Express app entry point
│   ├── routes/
│   │   └── interview.js      # /api/start, /api/answer, /api/end, /api/integrity-event
│   └── services/
│       └── aiService.js      # Question generation, adaptive follow-ups, evaluation
├── public/
│   ├── index.html            # UI
│   ├── style.css
│   └── app.js                # Speech I/O, chat flow, webcam integrity monitoring
├── package.json
├── .env.example
└── README.md
```

---

## 🧪 Minimum conditions this prototype satisfies

- [x] Accepts a candidate profile (resume text) + target role
- [x] Generates personalized, role-relevant questions
- [x] Conducts the interview as a back-and-forth conversation, not a static form
- [x] Adapts follow-up questions based on the quality/length of each answer
- [x] Supports spoken interaction (mic input + spoken questions)
- [x] Monitors webcam presence and tab focus during the session
- [x] Logs integrity events with timestamps
- [x] Produces a final evaluation report covering strengths, gaps, integrity notes, and a recommendation
- [x] Works with **zero external API keys** (demo mode), and upgrades automatically to a real LLM if a key is supplied

### Possible next steps (not required for the prototype, but natural extensions)
- Persist sessions to a real database instead of in-memory storage
- Add resume file upload (PDF/DOCX) instead of paste-only
- Add authentication for recruiter vs. candidate views
- Replace face-api.js with a more robust gaze-tracking model

---

## 📤 How to upload this project to your own GitHub

Follow these steps exactly, in order, from a terminal in the `ai-interview-bot` folder.

### 1. Create a new empty repository on GitHub
- Go to https://github.com/new
- Give it a name, e.g. `ai-interview-bot`
- **Do NOT** check "Add a README" or "Add .gitignore" (this project already has them)
- Click **Create repository**
- Copy the repository URL it shows you, e.g. `https://github.com/YOUR_USERNAME/ai-interview-bot.git`

### 2. Initialize git in this project folder
```bash
cd ai-interview-bot
git init
git add .
git commit -m "Initial commit: AI-Powered Interview Bot prototype"
```

### 3. Connect it to your GitHub repository
```bash
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ai-interview-bot.git
```

### 4. Push it up
```bash
git push -u origin main
```

If prompted for credentials and you have 2FA enabled, GitHub will ask for a **Personal
Access Token** instead of your password:
- Create one at https://github.com/settings/tokens → "Generate new token (classic)"
- Give it `repo` scope
- Paste it in place of your password when prompted

### 5. Confirm
Refresh your GitHub repo page — you should see all the project files there.

From then on, whenever you make changes:
```bash
git add .
git commit -m "Describe your change"
git push
```

---

## ⚠️ Note on the `.env` file
Never commit your real `.env` file with an API key inside it — `.gitignore` already
excludes it. Only `.env.example` (with no real key) gets pushed to GitHub.

// ---------- State ----------
let sessionId = null;
let attentionLostCount = 0;
let faceApiReady = false;
let integrityInterval = null;

const setupScreen = document.getElementById("setupScreen");
const interviewScreen = document.getElementById("interviewScreen");
const reportScreen = document.getElementById("reportScreen");
const chatLog = document.getElementById("chatLog");
const answerInput = document.getElementById("answerInput");
const integrityLog = document.getElementById("integrityLog");
const integrityStatus = document.getElementById("integrityStatus");

// ---------- Mode badge ----------
fetch("/api/health")
  .then((r) => r.json())
  .then((d) => {
    document.getElementById("modeBadge").textContent =
      d.mode === "llm-powered" ? "🤖 LLM-powered" : "⚙️ Rule-based demo mode";
  })
  .catch(() => {
    document.getElementById("modeBadge").textContent = "offline";
  });

// ---------- Chat helpers ----------
function addMessage(text, from) {
  const div = document.createElement("div");
  div.className = `msg ${from}`;
  const label = document.createElement("span");
  label.className = "label";
  label.textContent = from === "bot" ? "Interviewer" : "You";
  div.appendChild(label);
  const body = document.createElement("div");
  body.textContent = text;
  div.appendChild(body);
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = 1;
  window.speechSynthesis.speak(utter);
}

// ---------- Start interview (Feature 1) ----------
document.getElementById("startBtn").addEventListener("click", async () => {
  const role = document.getElementById("roleInput").value.trim();
  const resume = document.getElementById("resumeInput").value.trim();
  if (!role || !resume) {
    alert("Please enter both a target role and your resume text.");
    return;
  }

  const res = await fetch("/api/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ role, resume })
  });
  const data = await res.json();
  if (data.error) return alert(data.error);

  sessionId = data.sessionId;
  setupScreen.classList.add("hidden");
  interviewScreen.classList.remove("hidden");

  addMessage(data.firstQuestion, "bot");
  speak(data.firstQuestion);

  if (document.getElementById("enableCamera").checked) {
    startIntegrityMonitoring();
  } else {
    startFocusTrackingOnly();
  }
});

// ---------- Submit answer (Feature 2: adaptive) ----------
async function submitAnswer() {
  const text = answerInput.value.trim();
  if (!text) return;
  addMessage(text, "user");
  answerInput.value = "";

  const res = await fetch("/api/answer", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId, answerText: text })
  });
  const data = await res.json();
  if (data.error) return alert(data.error);

  if (data.done) {
    return finishInterview();
  }
  const nextText = data.followUp || data.nextQuestion;
  addMessage(nextText, "bot");
  speak(nextText);
}

document.getElementById("submitAnswerBtn").addEventListener("click", submitAnswer);
answerInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    submitAnswer();
  }
});

// ---------- Speech-to-text mic button ----------
const micBtn = document.getElementById("micBtn");
let recognition = null;
let recognizing = false;

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  recognition.onresult = (e) => {
    const transcript = e.results[0][0].transcript;
    answerInput.value = (answerInput.value + " " + transcript).trim();
  };
  recognition.onend = () => {
    recognizing = false;
    micBtn.classList.remove("recording");
  };
} else {
  micBtn.title = "Speech recognition not supported in this browser";
}

micBtn.addEventListener("click", () => {
  if (!recognition) return alert("Speech recognition isn't supported in this browser. Try Chrome.");
  if (recognizing) {
    recognition.stop();
    return;
  }
  recognizing = true;
  micBtn.classList.add("recording");
  recognition.start();
});

// ---------- Feature 3: Interview Integrity Monitoring ----------
async function startIntegrityMonitoring() {
  const video = document.getElementById("webcam");
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
  } catch (e) {
    logIntegrity("Camera access denied — falling back to tab-focus tracking only.");
    return startFocusTrackingOnly();
  }

  // Try to load face-api.js tiny model from CDN. If offline/unavailable,
  // gracefully degrade to tab-focus tracking only.
  try {
    const MODEL_URL = "https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/weights";
    await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
    faceApiReady = true;
    logIntegrity("Face detection model loaded. Monitoring attention...");
  } catch (e) {
    logIntegrity("Could not load face-detection model (offline?). Using tab-focus tracking only.");
  }

  startFocusTrackingOnly();

  if (faceApiReady) {
    integrityInterval = setInterval(async () => {
      try {
        const result = await faceapi.detectSingleFace(video, new faceapi.TinyFaceDetectorOptions());
        if (!result) {
          registerAttentionEvent("face_not_detected", "No face detected in frame");
        }
      } catch (e) {
        // fail silently per-frame
      }
    }, 3000);
  }
}

function startFocusTrackingOnly() {
  window.addEventListener("blur", () => registerAttentionEvent("window_blur", "User switched away from the tab/window"));
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) registerAttentionEvent("tab_hidden", "Tab became hidden");
  });
}

function registerAttentionEvent(type, detail) {
  attentionLostCount += 1;
  logIntegrity(detail);
  integrityStatus.textContent = `Attention: ${attentionLostCount} flag(s)`;
  integrityStatus.className = attentionLostCount > 5 ? "integrity-status warn" : "integrity-status ok";

  if (sessionId) {
    fetch("/api/integrity-event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, type: "attention_lost", detail })
    }).catch(() => {});
  }
}

function logIntegrity(text) {
  const div = document.createElement("div");
  const time = new Date().toLocaleTimeString();
  div.textContent = `[${time}] ${text}`;
  integrityLog.prepend(div);
}

// ---------- Finish & report ----------
async function finishInterview() {
  clearInterval(integrityInterval);
  addMessage("That concludes the interview. Generating your evaluation report...", "bot");

  const res = await fetch("/api/end", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId })
  });
  const data = await res.json();

  interviewScreen.classList.add("hidden");
  reportScreen.classList.remove("hidden");
  renderReport(data.report, data.integrityEventCount);
}

function renderReport(report, integrityEventCount) {
  const el = document.getElementById("reportContent");
  el.innerHTML = `
    <p>${report.summary}</p>
    <h3>Strengths</h3>
    <ul>${report.strengths.map((s) => `<li>${s}</li>`).join("")}</ul>
    <h3>Gaps</h3>
    <ul>${report.gaps.map((g) => `<li>${g}</li>`).join("")}</ul>
    <h3>Integrity Note</h3>
    <p>${report.integrityNote} (${integrityEventCount} total event(s) logged)</p>
    <h3>Recommendation</h3>
    <p><strong>${report.recommendation}</strong></p>
  `;
}

document.getElementById("restartBtn").addEventListener("click", () => location.reload());
